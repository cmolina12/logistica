import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# Importar datos

df_r = pd.read_excel("Plantilla.xlsx",sheet_name="UltraCargo_Rutas_Transporte")
df_c = pd.read_excel("Plantilla.xlsx",sheet_name="UltraCargo_Centros_Logísticos")


# 1.1 Diseñar un grafo dirigido que represente la red completa de rutas disponibles, donde las ciudades
# serán los nodos y las rutas los arcos. Asegúrese de que en cada arco se calcule y muestre
# explícitamente el costo de la ruta con la fórmula de la empresa. Insertar la imagen del grafo generado
# en el inciso correspondiente.

def grafo_completo(df_r):
    
    G = nx.DiGraph()
    
    for _, row in df_r.iterrows():
        
        origen = row["Origen"]
        destino	= row["Destino"]
        distancia = row["Distancia"]
        velocidad = row["Velocidad"]
        frontera = row["Frontera"]
        alta_demanda = row["Alta_Demanda"]	
        capacidad = row["Capacidad"]
        horario = row["Horario"]
        terrestre = row["Terrestre"]
        aereo = row["Aereo"]
        vuelos = row["Vuelos"]
        
        
        # Cruza o no frontera
        
        flag_frontera = (1 if frontera == 1 else 0)
        
        # Alta demanda o no
        
        flag_alta_demanda = (1 if alta_demanda == 1 else 0)
        
        # Costo
        
        costo = 15*distancia+200*flag_frontera + (flag_alta_demanda*150)
        
        G.add_edge(origen,destino,costo=costo)
        
    return G

G = grafo_completo(df_r)

plt.figure(figsize=(12, 8), facecolor="white")
pos = nx.spring_layout(G)
nx.draw_networkx(
    G,
    pos,
    with_labels=True,
    node_color="lightblue",
    edge_color="gray",
    node_size=700,
    font_size=10,
)

# Mostrar los costos en las aristas
edge_labels = nx.get_edge_attributes(G, "costo")
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_color="green")

plt.title("Grafo Dirigido de Rutas de Transporte")
plt.axis("off")
plt.show()


# Un cliente ha solicitado el transporte de 20 toneladas de mercancía desde la ciudad de San Diego
# (EE.UU.) hasta Denver (EE. UU). Encuentre la ruta de menor costo. Reporte el costo total del transporte,
# la distancia total recorrida y el tiempo total que tomaría realizar la entrega. Para esto tenga en cuenta
# estas consideraciones:
# Si alguna de las rutas utilizadas supera la capacidad máxima permitida para su carga, se deberá
# aplicar un recargo adicional del 15% sobre el costo de esa ruta.
# • CUIDADO: Las rutas aéreas no podrán ser utilizadas después de las 11:00 horas.


CARGA = 20 #toneladas

def grafo_reducido(df_r):
   
    G = nx.DiGraph()
    
    for _, row in df_r.iterrows():
        
        origen = row["Origen"]
        destino	= row["Destino"]
        distancia = row["Distancia"]
        velocidad = row["Velocidad"]
        frontera = row["Frontera"]
        alta_demanda = row["Alta_Demanda"]	
        capacidad = row["Capacidad"]
        horario = row["Horario"]
        terrestre = row["Terrestre"]
        aereo = row["Aereo"]
        vuelos = row["Vuelos"]
        
        # Restriccion 1 - las rutas aereas no se pueden utilizar despues de las 11.00 horas
        
        if horario > 11 and aereo == 1:
            continue
        
        # Penalizacion - SI supero la carga maxima con las 20 toneladas
        
        if CARGA > capacidad:
            penalizacion = 0.15
        else:
            penalizacion = 0
        
        # Cruza o no frontera
        
        flag_frontera = (1 if frontera == 1 else 0)
        
        # Alta demanda o no
        
        flag_alta_demanda = (1 if alta_demanda == 1 else 0)
        
        
        # Costo
        
        costo = (15*distancia+200*flag_frontera + (flag_alta_demanda*150)) * (1+penalizacion)
        
        # tiempo 
        
        tiempo = distancia/velocidad
        
        G.add_edge(origen,destino,costo=costo,distancia=distancia,tiempo=tiempo)
    
    return G
        
G = grafo_reducido(df_r)

ruta = nx.shortest_path(G, source="San Diego",target="Denver",weight="costo")


# Sacar costo total, distancia total, tiempo total
    

# Calcular el costo total, distancia total y tiempo total de la ruta de menor costo monetario
def calcular_costos_ruta(G, ruta):
    costo_total = 0  # Inicializar costo total
    distancia_total = 0  # Inicializar distancia total
    tiempo_total = 0  # Inicializar tiempo total

    for i in range(
        len(ruta) - 1
    ):  # Iterar sobre cada tramo de la ruta excepto el ultimo (porque no tiene destino)
        origen = ruta[i]  # Nodo origen
        destino = ruta[i + 1]  # Nodo destino
        edge_data = G.get_edge_data(
            origen, destino
        )  # Obtener los datos de la arista, esto devuelve un diccionario con los atributos de la arista
        if edge_data is None:
            print(
                f"No hay arista entre {origen} y {destino} con las restricciones dadas."
            )
        costo_total += edge_data["costo"]  # Sumar el costo de la arista al costo total
        distancia_total += edge_data[
            "distancia"
        ]  # Sumar la distancia de la arista a la distancia total
        tiempo_total += edge_data[
            "tiempo"
        ]  # Sumar el tiempo de la arista al tiempo total

    return costo_total, distancia_total, tiempo_total


costo_total, distancia_total, tiempo_total = calcular_costos_ruta(G, ruta)
print("")
print(f"Ruta de menor costo de San Diego a Denver: { "->".join(ruta) }")
print(f"Costo total de la ruta: {costo_total}")
print(f"Distancia total de la ruta: {distancia_total}")
print(f"Tiempo total de la ruta: {tiempo_total}")
print("")

# 1.3 Un segundo cliente requiere realizar un envío importante desde Guadalajara (México) hasta Miami
# (EE.UU.) en un tiempo mínimo de 70 horas. El cliente ha solicitado que el envío no llegue antes de este
# tiempo para garantizar que su equipo de logística en Miami esté disponible para recibir la carga sin costos
# adicionales por almacenamiento o manipulación. Por lo tanto, cualquier planificación de rutas debe
# considerar esta restricción de tiempo mínimo.
# Por otro lado, debido a la tormenta mencionada, todas las rutas terrestres que atraviesan el estado de
# Texas están cerradas hasta nuevo aviso, por lo que solo podrán emplearse rutas aéreas. Tenga en cuenta
# que los costos de las rutas aéreas ahora siguen la fórmula:


#𝑪𝒂é𝒓𝒆𝒐
#= 𝟓𝟎𝟎 + 𝟑 ∗ 𝒅𝒊𝒋 + 𝟓𝟎 ∗ 𝒙𝒊𝒋 (fórmula 2.2)

#donde:
#• 𝒅𝒊𝒋 es la distancia de la ruta.
#• 𝒙𝒊𝒋 es el número de vuelos programados para esa ruta.
#• Determine cuál es la mejor ruta que cumple la restricción de tiempo impuesta. Además, indique
#el costo total, la distancia total recorrida y el tiempo total de la entrega. Tenga en cuenta que en
#el caso de empate en costo, el criterio de elección es el de menor tiempo. En el caso de empate
#en tiempo, el criterio de elección es el de menor costo.

TIEMPO_MINIMO = 70 # horas

ciudad_a_estado = {}

for _, row in df_c.iterrows():
    ciudad_a_estado[row["Ciudad"]]=row["Estado"]
    
#ciudades_a_estados = {row["Ciudad"]: row["Estado"] for _, row in df_centros.iterrows()}

def grafo_reducido(df_r):
   
    G = nx.DiGraph()
    
    for _, row in df_r.iterrows():
        
        origen = row["Origen"]
        destino	= row["Destino"]
        distancia = row["Distancia"]
        velocidad = row["Velocidad"]
        frontera = row["Frontera"]
        alta_demanda = row["Alta_Demanda"]	
        capacidad = row["Capacidad"]
        horario = row["Horario"]
        terrestre = row["Terrestre"]
        aereo = row["Aereo"]
        vuelos = row["Vuelos"]
        tiempo = distancia/velocidad
        # Restriccion 1 - Si voy por Texas, solo puedo usar rutas aereas
        
        if ciudad_a_estado[origen] == "Texas" or ciudad_a_estado[destino] == "Texas":
            if aereo == 0:
                continue
            
        costo = 0

        # Costo adicional para rutas aereas
        
        if aereo == 1 and vuelos > 0:
            costo = 500 + 3 * distancia + 50 * vuelos
        elif terrestre == 1 and aereo == 0:
            costo = 15 * distancia + 200 * frontera + (150*alta_demanda)
        
        G.add_edge(
            origen,
            destino,
            costo=costo,
            tiempo=tiempo,
            distancia=distancia
            )
        
    return G

grafo_reducido = grafo_reducido(df_r)

print(list(grafo_reducido.nodes()))

import heapq

def dijkstra(grafo, source, target, tiempo_minimo):
    
    #[(costo, tiempo, nodo, ruta actual)]
    
    heap = [(0, 0, source, [source])]
    
    visitados = dict()
    
    visitados_orden = []
    
    precedencia = dict()
    
    while heap:
        
        costo_acumulado, tiempo_acumulado, nodo, ruta = heapq.heappop(heap)
        
        # Prinicipio de llegada
        
        if nodo == target:
            
            if tiempo_acumulado < tiempo_minimo:
                continue
            else:
                distancia = sum(grafo[ruta[i]][ruta[i+1]]['distancia'] for i in range(len(ruta)-1))
                
                return ruta, costo_acumulado, tiempo_acumulado, distancia, precedencia, visitados_orden
            
        # Principio de optimalidad
        
        clave = (nodo, tiempo_acumulado)
        
        if clave in visitados and visitados[clave] <= (costo_acumulado):
            continue
        visitados[clave] = costo_acumulado
        
        for vecino in grafo.neighbors(nodo):
            
            
            # Evitar ciclos
            if vecino in ruta:
                continue
            
            visitados_orden.append(vecino)
            
            arco = grafo.get_edge_data(nodo, vecino)
            
            costo_nuevo = costo_acumulado + arco["costo"]
            
            tiempo_nuevo = tiempo_acumulado + arco["tiempo"]
            
            nodo_nuevo = vecino
            
            precedencia[vecino] = nodo
            
            heapq.heappush(heap, (costo_nuevo, tiempo_nuevo, nodo_nuevo, ruta + [vecino]))
            
    return None, float("inf"), float("inf"), float("inf")



ruta, costo, tiempo, distancia, precedencias, visitados = dijkstra(grafo_reducido, "Guadalajara", "Miami", 70)
        
print(f"Ruta: {"->".join(ruta)}")
print(f"Costo de la ruta: {costo}")
print(f"Tiempo total de la ruta en horas: {tiempo}")
print(f"Distancia total en km de la ruta: {distancia}")
print(" -> ".join(visitados))
print("\nRelaciones de precedencia:")
for nodo, padre in precedencias.items():
    print(f"{padre} → {nodo}")

                
